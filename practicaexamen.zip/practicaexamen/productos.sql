DROP DATABASE IF EXISTS MiniTienda;
CREATE DATABASE IF NOT EXISTS MiniTienda;
USE MiniTienda;
drop user if exists 'recio'@'localhost';
create user if not exists 'recio'@'localhost'identified by '1234';
grant all privileges on MiniTienda.* to 'recio'@'localhost';

create table if not exists productos(
	id int auto_increment primary key,
    nombre varchar(20) not null,
    peso decimal(3,1) not null,
    fecha date not null,
    categoria enum('PESCADO', 'MARISCO', 'CEFALOPODOS')
);

insert into productos(nombre, peso, fecha, categoria) values
	('Besugo', 3.2, '2025-12-03', 'PESCADO'),
    ('Lubina', 2.2, '2025-12-03', 'PESCADO'),
    ('Rape', 1.2, '2025-12-03', 'PESCADO'),
    ('Cangrejo', 0.4, '2025-12-03', 'MARISCO'),
    ('Langostino', 0.2, '2025-12-03', 'MARISCO'),
    ('Pulpo', 3.2, '2025-12-03', 'CEFALOPODOS');
    
    select * from productos;