package com.example.practicaexamen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticaexamenApplicationTests {

	@Test
	void contextLoads() {
	}

}
