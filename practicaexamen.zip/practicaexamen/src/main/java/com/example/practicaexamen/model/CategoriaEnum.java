package com.example.practicaexamen.model;

public enum CategoriaEnum {
PESCADO, MARISCO, CEFALOPODOS
}
