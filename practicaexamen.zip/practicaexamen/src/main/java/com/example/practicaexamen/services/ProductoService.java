package com.example.practicaexamen.services;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.practicaexamen.model.Producto;
import com.example.practicaexamen.repository.ProductoRepository;

@Service
public class ProductoService {

    @Autowired 
    private ProductoRepository repository;


    public List<String> getListaProductos() { //Devuelve una lista con el nombre de todos los productos
        return repository.findAll().stream().map(Producto::getNombre).distinct().toList();
    }

    public List<Producto> getAllProductos() { //Devuelve todos los productos(todo)
        return repository.findAll();
    }

    public List<Producto> getRegistroProducto(String nombreProducto) { //Devuelve una lista con los datos de un producto a traves de un filtro por nombre del producto
        return repository.findAll()
        .stream()
        .filter(producto -> producto.getNombre().equalsIgnoreCase(nombreProducto))
        .toList();
    }

    public List<Producto> getRegistroByFecha(String fecha) { //Devuelve una lista con los productos que se han registrado en una fecha
        return repository.findAll()
        .stream()
        .filter(producto -> producto.getFecha().isEqual(LocalDate.parse(fecha)))
        .toList();
    }

    public void addProducto(Producto producto) { //Añade un producto nuevo comprobando que no sea nulo
        if(producto != null){
            repository.save(producto);
        }
    }

    public void actualizarPeso(Double peso, Integer id) { //Actualizo el peso de un producto
        Producto producto = repository.findById(id).orElse(null);
        producto.setPeso(peso);
        repository.save(producto);
    }

    public void eliminarRegistro(int id) {  //elimino producto por id
        repository.deleteById(id);
    }
    
}
