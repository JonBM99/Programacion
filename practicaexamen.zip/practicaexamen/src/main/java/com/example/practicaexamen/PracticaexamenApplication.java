package com.example.practicaexamen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticaexamenApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticaexamenApplication.class, args);
	}

}
