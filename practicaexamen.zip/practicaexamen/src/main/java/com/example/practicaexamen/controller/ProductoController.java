package com.example.practicaexamen.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.practicaexamen.model.Producto;
import com.example.practicaexamen.services.ProductoService;

@RestController
@RequestMapping("/all")
public class ProductoController {

    @Autowired 
    private ProductoService service;

    @GetMapping() //Get que devuelve una lista con los nombres de todos los productos
    public List<String> getListaProductos() {
        return service.getListaProductos();
    }

    @GetMapping("/registros") //Get que devuelve todos los productos como objeto
    public List<Producto> getAllRegistros() {
        return service.getAllProductos();
    }
    
    @GetMapping("/producto") //Get que devuelve los datos referentes a un producto concreto
    public List<Producto> getRegistroProducto(@RequestParam String nombreProducto) {
        return service.getRegistroProducto(nombreProducto);
    }
    
    @GetMapping("/productoFormulario") //hace lo mismo que la de arriba pero si tuvieramos que hacer un formulario
    public List<Producto> gedRegistroProductoBody(@RequestBody String nombreProducto) {
        return service.getRegistroProducto(nombreProducto);
    }
    
    @GetMapping("/registros/fecha") //Get que devuelve productos registrados en una fecha
    public List<Producto> getRegistroByFecha(@RequestParam String fecha) {
        return service.getRegistroByFecha(fecha);
    }
    
    @PostMapping()
    public void postProducto(@RequestBody Producto producto) {  //Post para añadir un producto nuevo
        producto.setId(0);
        service.addProducto(producto);
    }
    
    @PutMapping("/{id}/actualizapeso")  //Put para actualizar el peso
    public void actualizarPeso(@PathVariable int  id, @RequestParam Double peso) {
        service.actualizarPeso(peso, id);
    }

    @DeleteMapping("{id}/eliminarRegistro")
    public void eliminarRegistro(@PathVariable int id){
        service.eliminarRegistro(id);
    }
}
